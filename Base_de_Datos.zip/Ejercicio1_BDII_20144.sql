                                       /*   REPASO  N�1   */
                               /*  TALLER DE BD  2014   */

/* Crear la BD con ruta especificada por el usuario */
Create Database Practica1MN
On
(Name=Practica1MN_Dat,
FileName='C:\MartesN\Practica1MN_Dat.Mdf',
Size=5,
MaxSize=10,
FileGrowth=1)

Log on

(Name='Practica1MN_Log',
FileName='C:\MartesN\Practica1MN_Log.Ldf',
Size=2MB,
MaxSize=5MB,
FileGrowth=1MB)

/*Seleccionar automaticamente la BD para trabajar en ella  */
Use Practica1MN

/* Eliminar ka BD, no importaqndo que este en uso */
Drop Database Practica1MN


                    /* ============== 0000000 ============= */ 

                             /*  MODELO DE DATOS UTILIZANDO   */
                             /*   TERCERA FORMA  RELACIONAL    */ 
                           /* USO DE  CONFIRMACION DE INDICE  */
          
Create Table Ciudad(
CodCiudad char(4) Constraint Pk_CodCiudad_Ciudad  Primary Key (CodCiudad),
Nombre varchar(15),  
 )
    
Create Table Comuna(
CodComuna char(4) Constraint  PK_CodComuna_Comuna Primary Key(CodComuna),
Nombre varchar(15),
) 
         
Create Table Haberes(
Codigo char(4) Constraint  PK_Codigo_Haberes Primary Key(Codigo),
SBase numeric(6),
Gratificacion numeric(6),
Aguinaldo numeric(6),
HrsExtras numeric(2)    
) 

Create Table DctoDetalle(
CodDetalle char(6) Constraint  PK_CodDetalle_DctoDetalle Primary Key(CodDetalle),
Anticipo numeric(6),
Prestamo numeric(6),
DctoAfp numeric(6)       
)