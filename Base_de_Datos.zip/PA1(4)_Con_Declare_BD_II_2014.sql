                              /*    PROCEDIMIENTO   CON  DECLARE    */
                              /*      MOVIMIENTO DE FACTURAS     */
                                             /*        1  TABLA        */
                              
 Create DataBase  PA1TMN 
On 
(Name=PA1TMN_Dat,
FileName='C:\PAlmacenadoMN\PA1TMN_Dat_Mdf',
Size=5,
MaxSize=10,
Filegrowth=1)

Log On

(Name='PA1TMN_Log',
FileName='C:\PAlmacenadoMN\PA1TMN_Log_ldf',
Size=2Mb,
MaxSize=5Mb,
Filegrowth=1Mb)

Drop DataBase PA1TMN
Use PA1TMN

Create Table Factura(
Rut char(12) Constraint Pk_Rut_Factura Primary Key (Rut),
NomCliente varchar(15),
RutEmpresa char(12) ,
NumFactura numeric,
Producto1 varchar(15),
Cantidad1 numeric(4),
ValProducto1 numeric,
Utilidad15 numeric,
Producto2 varchar(15),
Cantidad2 numeric(4),
ValProducto2 numeric,
Utilidad10 numeric,
ValTotal numeric,
Iva numeric,
ValPagar numeric,
Dcto1 numeric,
Dcto2 numeric,
Dcto3 numeric,
FormaPago varchar(15),
TotalFinalPagar numeric
)

Select * From Factura

Insert Into Factura values('11.111.111-1','JPerez1','11.111.111-9',111,'PFritas',100,
1000,150000,'Helados',200,2000,140000,230000,40000,347800,30000,64000,
18300,'Efectivo',420000)

Select * From Factura

                         /*    Creacion del Procedimiento  con Declare    */

Create Procedure MovimientoFactura
@RRut char(12),
@NNomCli varchar(15),
@RRutE char(12) ,
@NNumFact numeric,
@PProd1 varchar(15),
@CCant1 numeric(4),
@VValProd1 numeric,
@PProd2 varchar(15),
@CCant2 numeric(4),
@VValProd2 numeric,
@FPago varchar(15)

AS

Declare @RR numeric
Declare @Uti15 numeric
Declare @Uti10 numeric
Declare @VVTot numeric
Declare @IIva numeric
Declare @VValPag numeric
Declare @DDect1 numeric
Declare @DDect2 numeric
Declare @DDect3 numeric
Declare @TTotFinPag numeric

Set @Uti15 =(( @CCant1 * @VValProd1  ) * 0.15)
Set @Uti10 =(( @CCant2 * @VValProd2  ) * 0.10)

Set @VVTot =((( @CCant1 * @VValProd1  ) + @Uti15)) +
                       ((( @CCant2 * @VValProd2  ) + @Uti10))
Set @IIva =(@VVTot  * 0.19)
Set @VValPag =(@VVTot  + @IIva )

/*  If del Descuento  N�1  */
if ( @VValPag >= 100000 )
    Begin
          Set @DDect1 = ( @VValPag * 0.10 )   
    End
Else   
    Begin
         Set @DDect1 = 0 
    End

/*  If del Descuento  N�2  */
if ( @FPago ='Efectivo' )
    Begin
          Set @DDect2 = ( @VValPag * 0.20 )   
    End    
Else   if ( @FPago ='Cheque' )
    Begin
         Set @DDect2 = ( @VValPag * 0.10 )
    End
Else   if ( @FPago ='Credito' )
    Begin
         Set @DDect2 = 0 
    End
else 
    Begin
         Set @DDect2 = 0 
    End   

/*  If del Descuento  N�3  */
if ( (@DDect1 + @DDect2 )  < = 50000 )
    Begin
          Set @DDect3 = 10000
    End    
else 
    Begin
         Set @DDect3 = 0 
    End   

Set @TTotFinPag =( @VValPag ) - ( @DDect1 + @DDect2 + @DDect3 )

/*  Insertar las variables del procedimiento en la tabla   */
Insert Into Factura Values(@RRut,@NNomCli,@RRutE,@NNumFact,@PProd1,
@CCant1,@VValProd1,@Uti15,@PProd2,@CCant2,@VValProd2,@Uti10,@VVTot,
@IIva,@VValPag,@DDect1,@DDect2,@DDect3,@FPago,@TTotFinPag )            

Execute MovimientoFactura '22.222.222-2','JPerez2','22.222.222-9' ,
112,'Lomito',22,4000,'Bebidas',15,1000,'Efectivo'

Execute MovimientoFactura '33.222.222-3','JPerez2','33.222.222-9' ,
112,'Lomito',22,4000,'Bebidas',15,1000,'Cheque'

Execute MovimientoFactura '44.222.222-4','JPerez2','44.222.222-9' ,
112,'Lomito',22,4000,'Bebidas',15,1000,'Credito'

Select * From Factura
 
 