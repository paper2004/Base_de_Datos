                                         /*   REPASO  N�1   */
                                    /*  TALLER DE BD  2014   */

/* Crear la BD con ruta especificada por el usuario */
Create DataBase Repaso1MT
On
(Name=Repaso1MT_Dat,
FileName ='C:\MartesT\Repaso1MT_Dat.Mdf',
Size=5,
MaxSize=10,
FileGrowth=1)

Log On

(Name='Repaso1MT_Log',
FileName ='C:\MartesT\Repaso1MT_Log.Ldf',
Size=2MB,
MaxSize=5MB,
FileGrowth=1MB)

/*Seleccionar automaticamente la BD para trabajar en ella */
Use Repaso1MT

/* Eliminar ka BD, no importaqndo que este en uso */
Drop Database Practica1MM
 
 
                      /* ============== 0000000 ============= */ 

                             /*  MODELO DE DATOS UTILIZANDO   */
                             /*   TERCERA FORMA  RELACIONAL    */ 
                           /* USO DE  CONFIRMACION DE INDICE  */
          
          
    Create Table Ciudad(
    CodCiudad char(4) Constraint  PK_CodCiudad_Ciudad Primary Key(CodCiudad),
    Nombre varchar(15),
    )             
             
    Create Table Comuna(
    CodComuna char(4) Constraint  PK_CodComuna_Comuna Primary Key(CodComuna),
    Nombre varchar(15),
    ) 
         
    Create Table Haberes(
    Codigo char(4) Constraint  PK_Codigo_Haberes Primary Key(Codigo),
    SBase numeric(6),
    Gratificacion numeric(6),
    Aguinalto numeric(6),
    HrsExtras numeric(2)    
    )               
    
    Create Table DctoDetalle(
    CodDetalle char(6) Constraint  PK_CodDetalle_DctoDetalle Primary Key(CodDetalle),
    Anticipo numeric(6),
    Prestamo numeric(6),
    DctoAfp numeric(6)       
    )     
    
    Create Table Descuento(
    Codigo char(4) Constraint  PK_Codigo_Descuento Primary Key(Codigo),
    Descripcion varchar(15),
    DetalleDcto char(6) Constraint  FK_DetalleDcto_Descuento Foreign Key (DetalleDcto)
    references DctoDetalle (CodDetalle) ,
    Autorizado varchar(15),      
    )
   
    Create Table DPersonal(
    Rut char(12) Constraint  PK_Rut_DPersonal Primary Key(Rut),
    Nombre varchar(15),
    Apellido varchar(15),
    Direccion varchar(15),
    Sexo char(1),
    Edad  numeric(2),
    EstCivil varchar(15),
    Comuna char(6) Constraint  FK_Comuna_DPersonal Foreign Key (Comuna) references Comuna (CodComuna) ,
    Ciudad char(4) Constraint  FK_Ciudad_DPersonal Foreign Key (Ciudad)  references Ciudad (CodCiudad) ,          
    )                
                           
                           
                           
                            