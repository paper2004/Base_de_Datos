                                                           /*PROCEDIMIENTO  N�1*/
                                                                /*SIN DECLARE*/

Drop database Ejemplo1PA

Create database Ejemplo1PA
On
(Name=Ejemplo1PA_dat,
Filename = 'C:\Practica1PA\Ejemplo1PA_dat.mdf',
Size=5,
Maxsize=10,
Filegrowth=1)

Log on

(Name='Ejemplo1PA_log',
Filename = 'C:\Practica1PA\Ejemplo1PA_log.ldf',
Size=2mb,
Maxsize=5mb,
Filegrowth=1mb)

Use Ejemplo1PA
Drop Table Sueldos

Create table Sueldos(
Rut char(12) primary key,
Nombre varchar(15),
Direccion varchar(15),
SBase numeric,
Bono numeric,
Aguinaldo numeric,
N_Tot_Hrs_Ext numeric(2),
N_Hrs_Ext_H numeric(2),
N_Hrs_Ext_F numeric(2),
Valor_Hrs_Ext_H numeric,
Valor_Hrs_Ext_F numeric,
Valor_Tot_Hrs_Ext numeric,
Gratifica numeric,
Dcto_Afp numeric,
Dcto_Isapre numeric,
Dias_Trabajo numeric(2),
Dias_Ausente numeric(2),
Dias_Trabajados numeric(2),
Anticipo numeric,
SLiquido numeric
);

Insert Into sueldos Values('11.111.111-1','Juan Perez','Cuevas 456',
300000,20000,15000,20,10,10,40000,1500,1200,30000,38500,28000,
30,0,30,150000,240000)

Insert Into sueldos Values('22.222.222-2','Juan Perez2','Alameda 213',
400000,40000,18000,20,10,10,40000,1600,1300,20000,38500,38000,
30,1,29,20000,340000)

Select * From Sueldos


      /* CREACION DEL PROCEDIMIENTO LLAMADO  CALCULOSUELDO*/

Drop Procedure CalculoSueldo

Create Procedure CalculoSueldo
@Rutt char(12),
@Nombre varchar(15),
@Direccion varchar(15),
@N_Hrs_Ext_H numeric(2),
@N_Hrs_Ext_F numeric(2),
@Dias_Ausente numeric(2),
@SBase numeric,
@Bono numeric,
@Aguinaldo numeric,
@Valor_Hrs_Ext_H numeric,
@Valor_Hrs_Ext_F numeric,
@Gratifica numeric,
@Dcto_Afp numeric,
@Dcto_Isapre numeric,
@Dias_Trabajo numeric(2),
@Dias_Trabajados numeric(2),
@Anticipo numeric,
@N_Tot_Hrs_Ext numeric(2),
@Valor_Tot_Hrs_Ext numeric,
@SLiquido numeric

AS

set @Dias_Trabajo=30
set @Dias_Trabajados=@Dias_Trabajo-@Dias_Ausente
set @SBase=@Dias_Trabajados * 8000
set @Bono=@SBase * 0.25
set @Aguinaldo=35000
set @N_Tot_hrs_Ext = @N_Hrs_Ext_H + @N_Hrs_Ext_F
set @Valor_Hrs_Ext_H=(@SBase*0.00729)+1000
set @Valor_Hrs_Ext_F=@Valor_Hrs_Ext_H * 2
set @Valor_Tot_Hrs_Ext=(@Valor_Hrs_Ext_H * @N_Hrs_Ext_H) + (@Valor_Hrs_Ext_F * @N_Hrs_Ext_F)
set @Gratifica=(@SBase*0.1)+(@Bono*0.1)
set @Dcto_Afp=(@SBase+@Bono+@Aguinaldo)*0.1
set @Dcto_Isapre=(@SBase+@Bono+@Aguinaldo+@Gratifica)*0.05
set @Anticipo= @SBase*0.5
set @SLiquido=(@SBase+@Bono+@Aguinaldo+@Gratifica+@Valor_Tot_Hrs_Ext)-(@Dcto_Afp + @Dcto_Isapre + @Anticipo)

Insert Into Sueldos Values(@Rutt,@Nombre,@Direccion,@SBase,@Bono,@Aguinaldo,@N_Tot_Hrs_Ext,@N_Hrs_Ext_H,@N_Hrs_Ext_F,
@Valor_Hrs_Ext_H,@Valor_Hrs_Ext_F,@Valor_Tot_Hrs_Ext,@Gratifica,@Dcto_Afp,@Dcto_Isapre,@Dias_Trabajo,
@dias_ausente,@dias_trabajados,@anticipo,@sliquido)

execute calculosueldo '66.555.555-5','Juan Perez','Alameda 11',
10,2,3,Null,Null,Null,Null,Null,Null,Null,Null,Null,Null,Null,Null,Null,Null

select * from sueldos



