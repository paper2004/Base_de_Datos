/*Proceso almacenado de Prueba*/

create database prueba1
on
(name=prueba1_dat,
filename='c:\prueba1\prueba1_dat.mdf',
size=5,
maxsize=10,
filegrowth=1)

log on

(name=prueba1_log,
filename='c:\prueba1\prueba1_log.ldf',
size=2mb,
maxsize=5mb,
filegrowth=1mb)


create table dpersonal(
rut char(12) constraint pk_rut_dpersonal primary key (rut),
nombre varchar(50),
cargo varchar(30),
departamento varchar(20),
sliquido numeric
)

create table haberes(
codigo_trab char(3) constraint Pk_codigo_trab_haberes primary key (codigo_trab),
rut_trab char(12) constraint fk_rut_dpersonal foreign key references dpersonal(rut),
sbase numeric,
bono numeric,
aguinaldo numeric
)

create table descuentos(
codigo_trab char(3) constraint Pk_codigo_trab_descuentos primary key (codigo_trab),
rut_trab char(12) constraint fk_rut_dpersonal foreign key references dpersonal(rut),
anticipo numeric,
afp numeric,
prestamo numeric
)

drop procedure calculosueldos

create procedure calculosueldos
@rrut char(12),
@nnombre varchar(50),
@ccargo varchar(30),
@ddepartamento varchar(20),
@ssliquido numeric


as

declare @ssbase numeric
declare @bbono numeric
declare @aaguinaldo numeric
declare @aanticipo numeric
declare @aafp numeric
declare @pprestamo numeric

